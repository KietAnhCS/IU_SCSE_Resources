package excersice4;

import java.util.List;

public class Order {
	private int id;
	private List<Item> items;

	public Order(int id, List<Item> items) {
		this.id = id;
		this.items = items;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public List<Item> getItems() {
		return items;
	}

	public void setItems(List<Item> items) {
		this.items = items;
	}

	// Tính trung bình giá sản phẩm
	public double calculateAverageCost() {
		if (items.isEmpty())
			return 0;

		double totalCost = 0;
		for (Item item : items) {
			totalCost += item.getPrice();
		}
		return totalCost / items.size();
	}
}
