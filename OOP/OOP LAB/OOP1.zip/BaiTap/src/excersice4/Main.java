package excersice4;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        List<Item> items = new ArrayList<>();

        System.out.print("Enter Order ID: ");
        int orderId = scanner.nextInt();

        System.out.print("Enter number of items: ");
        int itemCount = scanner.nextInt();

        // Nhập thông tin sản phẩm
        for (int i = 0; i < itemCount; i++) {
            System.out.println("Enter details for item " + (i + 1) + ":");
            System.out.print("ID: ");
            int itemId = scanner.nextInt();
            scanner.nextLine(); // Đọc bỏ dòng trống

            System.out.print("Name: ");
            String itemName = scanner.nextLine();

            System.out.print("Price: ");
            double itemPrice = scanner.nextDouble();

            items.add(new Item(itemId, itemName, itemPrice));
        }

        // Tạo đơn hàng
        Order order = new Order(orderId, items);

        // Tính và hiển thị giá trung bình
        double averageCost = order.calculateAverageCost();
        System.out.printf("The average cost of items in Order %d is: %.2f\n", orderId, averageCost);

        scanner.close();
    }
}

