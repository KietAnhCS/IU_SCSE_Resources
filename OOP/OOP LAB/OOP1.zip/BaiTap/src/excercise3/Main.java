package excercise3;

import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);

		System.out.print("Enter x-coordinate of point A: ");
		double xA = scanner.nextDouble();
		System.out.print("Enter y-coordinate of point A: ");
		double yA = scanner.nextDouble();

		System.out.print("Enter x-coordinate of point B: ");
		double xB = scanner.nextDouble();
		System.out.print("Enter y-coordinate of point B: ");
		double yB = scanner.nextDouble();

		Point pointA = new Point(xA, yA);
		Point pointB = new Point(xB, yB);

		double distance = pointA.distance(pointB);

		System.out.printf("The distance between A and B is: %.2f\n", distance);

		scanner.close();
	}

}
