package exercise1;

public class Rectangle {
    private int width;
    private int height;
    private String errorMessage = ""; // New field to store error messages
    
    public Rectangle(int width, int height) {
        if (width < 0) {
            errorMessage += "Error: Width cannot be negative. Setting width to default: 1\n";
            this.width = 1;
        } else {
            this.width = width;
        }
        
        if (height < 0) {
            errorMessage += "Error: Height cannot be negative. Setting height to default: 1\n";
            this.height = 1;
        } else {
            this.height = height;
        }
    }
    
    public int getHeight() {
        return height;
    }
    
    public int getWidth() {
        return width;
    }
    
    // Method to display rectangle as * to the screen
    public void visualize() {
    	
        // Loop for height
        for (int heightIndex = 0; heightIndex < height; heightIndex++) {
            // Loop for width
            for (int widthIndex = 0; widthIndex < width; widthIndex++) {
                System.out.print("*");
            }
            // Next line after printed all * of width
            System.out.println();
        }
        
        if (!errorMessage.isEmpty()) {
            System.out.print(errorMessage);
        }
        
        System.out.println();
    }
}