package exercise1;

public class TestRectangle {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Rectangle rec1 = new Rectangle(7, 5);
		Rectangle rec2 = new Rectangle(-3, 2);
		Rectangle rec3 = new Rectangle(3, 1);
		Rectangle rec4 = new Rectangle(2, 4);
		Rectangle rec5 = new Rectangle(5, 3);

		System.out.println("Rectangle 1: Width = " + rec1.getWidth() + "; Height = " + rec1.getHeight());
		rec1.visualize();

		System.out.println("Rectangle 2: Width = " + rec2.getWidth() + "; Height = " + rec2.getHeight());
		rec2.visualize();

		System.out.println("Rectangle 3: Width = " + rec3.getWidth() + "; Height = " + rec3.getHeight());
		rec3.visualize();

		System.out.println("Rectangle 4: Width = " + rec4.getWidth() + "; Height = " + rec4.getHeight());
		rec4.visualize();

		System.out.println("Rectangle 5: Width = " + rec5.getWidth() + "; Height = " + rec5.getHeight());
		rec5.visualize();
	}

}
