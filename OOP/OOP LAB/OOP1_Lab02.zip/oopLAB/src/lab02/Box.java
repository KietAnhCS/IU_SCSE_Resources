package lab02;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class Box {

	private static final int WIDTH = 10;
	private static final int HEIGHT = 10;

	// This is for the singleton pattern: only one Box object can exist
	private static Box instance;

	// A list to store all the particles in the box
	private List<Particle> particles;

	// A Random object to generate random numbers (for particle placement and movement)
	private Random random;

	// Private constructor: Only this class can create a Box object (for singleton
	// pattern)
	private Box() {
		// Initialize the list of particles as an empty ArrayList
		particles = new ArrayList<>();
		// Create a new Random object for generating random numbers
		random = new Random();
		// Add 3 random particles to start with
		for (int i = 0; i < 3; i++) {
			addRandomParticle();
		}
	}

	// This method ensures only one Box object exists (singleton pattern)
	// If no Box exists, it creates one; otherwise, it returns the existing one
	public static Box getInstance() {
		if (instance == null) {
			instance = new Box();
		}
		return instance;
	}

	public int getWidth() {
		return WIDTH;
	}

	public int getHeight() {
		return HEIGHT;
	}

	// Getter method to get a copy of the list of particles
	// We return a copy so the original list can't be modified from outside
	public List<Particle> getParticles() {
		return new ArrayList<>(particles);
	}

	// Method to add a new particle at a random position in the box
	private void addRandomParticle() {
		// Generate random x and y coordinates within the box (0 to WIDTH-1, 0 to
		// HEIGHT-1)
		int x = random.nextInt(WIDTH);
		int y = random.nextInt(HEIGHT);
		// Create a new particle at that position and add it to the list
		particles.add(new Particle(x, y));
	}

	// Method to move all particles in the box
	public void moveAllParticles() {
		// Loop through each particle in the list
		for (Particle p : particles) {
			// Pick a random direction from the Direction enum
			Particle.Direction direction = Particle.Direction.values()[random
					.nextInt(Particle.Direction.values().length)];
			// Move the particle in that direction, passing the box's width and height for
			// boundary checking
			p.move(direction, WIDTH, HEIGHT);
		}
		// After moving all particles, check for collisions
		checkCollisions();
	}

//Method to check if any particles have collided
	private void checkCollisions() {
		// Loop through each pair of particles to see if they are at the same position 
		for (int i = 0; i < particles.size(); i++) {
			for (int j = i + 1; j < particles.size(); j++) {
				// If two particles collide (same position)
				if (particles.get(i).collidesWith(particles.get(j))) {
					// Add a new random particle since two particles collided
					addRandomParticle();
					System.out.println("Collision detected at step, adding new particle. Total particles now: "
							+ particles.size());
				}
			}
		}
	}

	// Method to get the total number of particles in the box
	public int getParticleCount() {
		return particles.size();
	}

	// Method to visualize the box as a grid with the desired border style
	@Override
	public String toString() {
		// Build the string representation of the box
		StringBuilder sb = new StringBuilder();

		// Draw the top border (dashed line)
		for (int x = 0; x < WIDTH + 2; x++) {
			sb.append("-");
		}
		sb.append("\n");

		// Draw each row of the box
		for (int y = 0; y < HEIGHT; y++) {
			// Start each row with a vertical border "|"
			sb.append("|");

			// Draw the content of the row
			for (int x = 0; x < WIDTH; x++) {
				// Check if there is a particle at position (x, y)
				boolean hasParticle = false;
				for (Particle p : particles) {
					if (p.getX() == x && p.getY() == y) {
						sb.append("*"); // Print "*" if there's a particle
						hasParticle = true;
						break;
					}
				}
				if (!hasParticle) {
					sb.append(" "); // Print a space if there's no particle
				}
			}

			// End each row with a vertical border "|"
			sb.append("|\n");
		}

		// Draw the bottom border (dashed line)
		for (int x = 0; x < WIDTH + 2; x++) {
			sb.append("-");
		}
		sb.append("\n");

		return sb.toString();
	}
}