package lab02;

import java.util.Scanner;

public class Simulation {
    
    public void runSimulation(int steps) {
        // Get the single instance of the Box (using the singleton pattern)
        Box box = Box.getInstance();

        // Loop for the specified number of steps
        for (int step = 0; step < steps; step++) {
            // Print the current step number
            System.out.println("Step " + step + ":");
            // Move all particles in the box
            box.moveAllParticles();
            
            System.out.println("Number of particles: " + box.getParticleCount());
            // Print the visualization of the box
            System.out.println(box.toString());

            System.out.println("------------------------");
        }
    }

	
	public static void main(String[] args) {

		Scanner scanner = new Scanner(System.in);
		int simulationTimes;

		// Create a new Simulation object
		Simulation sim = new Simulation();

		System.out.println("Simulation steps: ");
		simulationTimes = scanner.nextInt();

		sim.runSimulation(simulationTimes); // Run the simulation

		scanner.close();
	}
}