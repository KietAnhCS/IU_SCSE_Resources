package lab02;

public class Particle {

    private int x;
    private int y;

    // Enum for the 8 possible directions a particle can move
    public enum Direction {
        NORTH, NORTH_EAST, EAST, SOUTH_EAST, SOUTH, SOUTH_WEST, WEST, NORTH_WEST
    }

    public Particle(int x, int y) {
        this.x = x; 
        this.y = y; 
    }

    public int getX() {
        return x;
    }

    public int getY() {
        return y;
    }

    // Method to move the particle in a given direction, but it can't move outside the box
    public void move(Direction direction, int width, int height) {
        // Create temporary variables for the new position after moving
        int newX = x;
        int newY = y;

        // Based on the direction, update the new coordinates
        switch (direction) {
            case NORTH: // Move up (decrease y by 1)
                newY -= 1;
                break;
            case NORTH_EAST: // Move up and right (decrease y by 1, increase x by 1)
                newX += 1;
                newY -= 1;
                break;
            case EAST: // Move right (increase x by 1)
                newX += 1;
                break;
            case SOUTH_EAST: // Move down and right (increase y by 1, increase x by 1)
                newX += 1;
                newY += 1;
                break;
            case SOUTH: // Move down (increase y by 1)
                newY += 1;
                break;
            case SOUTH_WEST: // Move down and left (increase y by 1, decrease x by 1)
                newX -= 1;
                newY += 1;
                break;
            case WEST: // Move left (decrease x by 1)
                newX -= 1;
                break;
            case NORTH_WEST: // Move up and left (decrease y by 1, decrease x by 1)
                newX -= 1;
                newY -= 1;
                break;
        }

        // Check if the new position is inside the box (between 0 and width/height)
        // If it's within bounds, update the particle's position
        if (newX >= 0 && newX < width && newY >= 0 && newY < height) {
            x = newX;
            y = newY;
        }
        // If the new position is outside the box, the particle stays where it is
    }

    // Method to check if this particle collides with another particle
    // Two particles collide if they are at the same position (same x and y)
    public boolean collidesWith(Particle other) {
        return this.x == other.x && this.y == other.y;
    }
}