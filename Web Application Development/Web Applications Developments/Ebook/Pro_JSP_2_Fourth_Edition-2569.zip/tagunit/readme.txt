Download Tagunit 1.0.1 from 
http://tagunit.sourceforge.net
and copy 

	tagunit.jar
			
to this directory.
