Download Cactus 1.7.1 from http://jakarta.apache.org/cactus/
and copy 

	aspectjrt-1.2.1.jar
	cactus-1.7.1.jar
	commons-httpclient-2.0.2.jar
	commons-logging-1.0.4.jar

to this directory.
