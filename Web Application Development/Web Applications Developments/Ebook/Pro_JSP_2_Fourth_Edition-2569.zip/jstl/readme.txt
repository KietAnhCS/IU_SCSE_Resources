Download JSP Standard Tag Library 1.1 from 
http://jakarta.apache.org/taglibs/doc/standard-doc/intro.html
and copy 

	jstl.jar
	standard.jar
		
to this directory.
