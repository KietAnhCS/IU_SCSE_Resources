Download Xalan 2.7.0 from 
http://xml.apache.org/xalan-j/downloads.html
and copy 

	xalan.jar
	serializer.jar
			
to this directory.
