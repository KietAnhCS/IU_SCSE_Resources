Download MySQL Connector/J from 
http://dev.mysql.com/downloads/connector/j/3.1.html
and copy 

	mysql-connector-java-3.1.11-bin.jar
			
to this directory.
