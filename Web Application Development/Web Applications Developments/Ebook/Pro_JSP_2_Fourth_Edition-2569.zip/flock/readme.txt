Download Flock 0.6 from http://flock.sourceforge.net/
and copy 

	commons-lang-1.0.jar
	jdom-1.0b8.jar
	log4j-1.2.6.jar
	
to this directory.
