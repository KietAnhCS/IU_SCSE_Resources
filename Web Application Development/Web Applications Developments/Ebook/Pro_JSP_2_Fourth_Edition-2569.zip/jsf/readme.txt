Download JavaServer Faces 1.1.01 from http://java.sun.com/j2ee/javaserverfaces/download.html
and copy 

	commons-beanutils.jar
	commons-collections.jar
	commons-digester.jar
	commons-logging.jar
	jsf-api.jar
	jsf-impl.jar
	
to this directory.
