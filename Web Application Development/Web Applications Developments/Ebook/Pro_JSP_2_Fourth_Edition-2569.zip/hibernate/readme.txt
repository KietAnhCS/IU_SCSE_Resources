Download Hibernate 3.0.5 from http://www.hibernate.org/6.html
and copy 

	antlr-2.7.5H3.jar
	asm.jar
	cglib-2.1.jar
	commons-collections-2.1.1.jar
	commons-logging-1.0.4.jar
	dom4j-1.6.jar
	ehcache-1.1.jar
	hibernate3.jar
	jta.jar
	
to this directory.
