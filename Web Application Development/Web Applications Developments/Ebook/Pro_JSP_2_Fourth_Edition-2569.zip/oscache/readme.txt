Download OSCache 2.2 from 
http://www.opensymphony.com/oscache/
and copy 

	oscache-2.2.jar
			
to this directory.
