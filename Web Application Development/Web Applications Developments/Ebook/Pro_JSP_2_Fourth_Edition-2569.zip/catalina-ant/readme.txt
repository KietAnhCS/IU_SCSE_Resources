Download Tomcat Deployer from http://tomcat.apache.org/download-55.cgi
and copy 

	catalina-ant.jar

to this directory.
