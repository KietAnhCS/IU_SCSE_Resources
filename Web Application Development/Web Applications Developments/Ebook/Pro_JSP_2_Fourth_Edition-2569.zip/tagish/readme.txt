Download Tagish 1.0.3 from 
http://free.tagish.net/jaas/
and copy 

	tagishauth.jar 
			
to this directory.
