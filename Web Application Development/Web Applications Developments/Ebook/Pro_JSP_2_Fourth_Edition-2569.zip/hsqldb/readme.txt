Download HSQLDB 1.8.0 from http://hsqldb.org/
and copy 

	hsqldb.jar
	
to this directory.
