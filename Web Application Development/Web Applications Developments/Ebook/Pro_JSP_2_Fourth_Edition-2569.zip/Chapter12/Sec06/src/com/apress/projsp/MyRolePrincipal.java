package com.apress.projsp;

public class MyRolePrincipal extends MyPrincipal {
  /** Creates a new instance of MyRolePrincipal */
  public MyRolePrincipal(String s) {
    super(s);
  }
}