Download Junit 3.8.1 from 
http://www.junit.org
and copy 

	junit.jar
			
to this directory.

Also, copy junit.jar to your Ant lib directory.
