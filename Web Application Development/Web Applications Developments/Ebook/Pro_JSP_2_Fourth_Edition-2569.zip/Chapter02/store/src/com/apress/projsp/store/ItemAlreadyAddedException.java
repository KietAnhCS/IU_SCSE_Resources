package com.apress.projsp.store;

import javax.servlet.ServletException;

public class ItemAlreadyAddedException extends ServletException {

}