﻿<!-- This website template is released 
under  a Creative Commons Attribution 2.5 License. 
We request you retain the full copyright notice below
including the link to www.securityguardjobsnow.com.

This not only gives respect to the large amount of time
given freely by the developers but also helps build
interest, traffic and use of our free and paid designs.

If you refuse to include even this then
support may be affected. You are allowed to use this
design only if you agree to the following conditions: - You
cannot remove copyright notice from this design without our
permission. -If you modify this design it still should
contain copyright because it is based on our work.- You may
copy, distribute, modify, etc... this template as long as
link to our website remains untouched. For support visit
http://www.mikeylong.com. -- >

Security Guard Jobs Now : 2010  -- >

 


About this Template:

These templates were created by Home Security 8, a home security destination site. 
(They were originally going to be part of syndication systems, but after the stock market crashed that was no longer a possibility, and they were repurposed for public distribution.)

-----------------------

Step 1: LOAD FONTS Find the fonts folder on your computer. It lists were you can download the fonts that are used in this template. You should add the fonts to your computer font’s folder if you have not done so already.

Step 2: CHANGE THE HTML TEXT: You will find text inside the HTML file that corresponds to the web site content. Much of this place holder text is “lorem ipsum” or is listed as “Demo Content”. You can change this content by using a text editor to change the content inside the HTML file.

Step 3: CHANGE TEXT INCLUDED IN IMAGES THROUGH PSD FILE: In order to make a professional quality template, we needed to include some of the text in the JPEG and GIF images.  This same text can be found in the PSD files that are included in the template. You will probably need to re-cut these JPEG and GIF files from the PSD files. This is tedious, but is required to produce the highest quality web sites.

Step 4: CREATING NEW PAGES: Just rename the inner.html file in any way that you wish to create new pages, and then link to these pages from the menu or interior of the web site.

STEP 5: CHANGE THE TITLE TAG AND META INFORMATION: This is very important if you want the web site to work in search engines.

------------------------------------

WHAT CAN YOU USE THESE WEB TEMPLATES FOR:  Anything ethical - No porn, gambling or Nigerian scams.

WHAT YOU CANNOT USE THIS WEB TEMPLATE FOR: Anything devious or unethical – No Porn, Gambling or stealing money from little old ladies. Please don’t redistribute this template under your own name in template web sites.

WHAT ABOUT LICENSING: Templates are licensed under GNU Licensing. As long as you don’t remove the link in the footer  you are in full compliance. You’re welcome to change, modify, add to, or subtract from this template in any way as long as the link remains in place.

------------------------------------



