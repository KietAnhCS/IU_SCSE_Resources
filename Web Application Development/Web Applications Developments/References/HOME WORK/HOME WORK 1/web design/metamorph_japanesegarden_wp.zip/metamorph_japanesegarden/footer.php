<!--footer begins -->
<div id="footer">
    <p>Copyright &copy; <?php echo date("Y",time()); ?> <?php echo bloginfo('name'); ?>. Powered by <a href="http://wordpress.org/">WordPress</a>.<br />
        WordPress Theme by <a href="http://www.metamorphozis.com/" title="Flash Templates" target="_blank">Flash Templates</a></p>
</div></div>

<div style="clear: both"></div>
</div>
<!-- footer ends-->
</body>
</html>
