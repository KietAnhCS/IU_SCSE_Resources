<?php get_header(); ?>
<!-- header ends -->
<!-- content begins -->
	<div id="left">
          <h2 class="center">Error 404 - Not Found</h2>
      </div>
     <div id="right">
                  <?php get_sidebar(); ?>	

	</div>
    
	 <div style="clear: both"></div>
         <!--content ends -->
<!--footer begins -->
	</div>
</div>
</div>
<?php get_footer(); ?>