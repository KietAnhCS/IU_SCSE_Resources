<?php get_header(); ?>
<div id="wrapper">
		<div id="main">
	<?php if (have_posts()) : ?>
	<?php $post = $posts[0]; // Hack. Set $post so that the_date() works. ?>
	<?php /* If this is a category archive */ if (is_category()) { ?>
	<h3><u>Archive for the '<?php echo single_cat_title(); ?>' Category</u></h3>

	<?php /* If this is a daily archive */ } elseif (is_day()) { ?>
	<h1>Archive for <?php the_time('F jS, Y'); ?></h1>

	<?php /* If this is a monthly archive */ } elseif (is_month()) { ?>
	<h3>Archive for <?php the_time('F, Y'); ?></h3>

	<?php /* If this is a yearly archive */ } elseif (is_year()) { ?>
	<h1>Archive for <?php the_time('Y'); ?></h1>

	<?php /* If this is a search */ } elseif (is_search()) { ?>
	<h1>Search Results</h1>

	<?php /* If this is an author archive */ } elseif (is_author()) { ?>
	<h1>Author Archive</h1>

	<?php /* If this is a paged archive */ } elseif (isset($_GET['paged']) && !empty($_GET['paged'])) { ?>
	<h1>Blog Archives</h1>
	<?php } ?>
		<?php while (have_posts()) : the_post(); ?>
			<h1><a href="<?php the_permalink() ?>" rel="bookmark"><?php the_title(); ?></a></h1>
			<p class="details">Posted on <?php the_time('F j, Y'); ?> - Filed Under <?php the_category(', ') ?> | <?php comments_popup_link('Leave a Comment', '1 Comment', '% Comments'); ?></p>
			<?php the_excerpt(__('Readmore �'));?><p style="margin-bottom:10px;"><a href="<?php the_permalink() ?>" style="margin:0 0 0px 2px;">Read More..&gt;&gt;</a></p>
			<?php endwhile; else: ?>
			<p><?php _e('Sorry, no posts matched your criteria.'); ?></p><?php endif; ?>
			<p><?php posts_nav_link(' &#8212; ', __('&laquo; go back'), __('keep looking &raquo;')); ?></p>
		</div>
	<?php include(TEMPLATEPATH."/left_sidebar.php");?>
	<?php include(TEMPLATEPATH."/right_sidebar.php");?>
<?php get_footer(); ?>