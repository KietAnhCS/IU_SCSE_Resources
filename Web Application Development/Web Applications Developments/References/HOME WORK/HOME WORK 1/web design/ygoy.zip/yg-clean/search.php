<?php get_header(); ?>
<div id="wrapper">
		<div id="main">
	<?php if (have_posts()) : ?>
	<?php $post = $posts[0]; // Hack. Set $post so that the_date() works. ?>
	<?php /* If this is a category archive */ if (is_category()) { ?>
	<h1><u>Archive for the '<?php echo single_cat_title(); ?>' Category</u></h1>

	<?php /* If this is a search */ } elseif (is_search()) { ?>
	<h3>Search Results for "<?php echo $s;?>"</h3>

	<?php /* If this is an author archive */ } elseif (is_author()) { ?>
	<h1>Author Archive</h1>

	<?php } ?>
		<?php while (have_posts()) : the_post(); ?>
			<h1><a href="<?php the_permalink() ?>" rel="bookmark"><?php the_title(); ?></a></h1>
			<p class="details">Posted on <?php the_time('F j, Y'); ?> - Filed Under <?php the_category(', ') ?> | <?php comments_popup_link('Leave a Comment', '1 Comment', '% Comments'); ?></p>
			<?php the_excerpt(__('Readmore �'));?><p style="border-bottom:1px dashed #ddd;padding-bottom:20px;"><a href="<?php the_permalink() ?>" style="margin:0 0 px 2px;">Read More..&gt;&gt;</a></p>
			<?php endwhile; else: ?>
			<p><?php _e('Sorry, no posts matched your criteria.'); ?></p><?php endif; ?>
			<p><?php posts_nav_link(' &#8212; ', __('&laquo; go back'), __('keep looking &raquo;')); ?></p>
		</div>
	<?php include(TEMPLATEPATH."/left_sidebar.php");?>
	<?php include(TEMPLATEPATH."/right_sidebar.php");?>
<?php get_footer(); ?>