<div style="clear: both;"></div>
</div>
<div id="footer" >
	Copyright &copy; 2007 - <?php bloginfo('name'); ?> - Theme Powered By - <a href="http://www.wordpress.org">Wordpress</a> - Design by <a href="http://www.ygoy.com">YGoY</a>
</div>
</div>


</body>
</html>