<?php get_header(); ?>
<div id="wrapper">
		<div id="main">
			<?php if (have_posts()) : while (have_posts()) : the_post(); ?>
			<h1><a href="<?php the_permalink() ?>" rel="bookmark"><?php the_title(); ?></a></h1>
			<p class="details">Posted on <?php the_time('F j, Y'); ?> </p>
			<?php the_content(__('Read more'));?>
			<p class="detailsb"> &#187; Filed Under <?php the_category(', ') ?> | <?php comments_popup_link('Leave a Comment', '1 Comment', '% Comments'); ?></p>
			<?php endwhile; else: ?>
			<p><?php _e('Sorry, no posts matched your criteria.'); ?></p><?php endif; ?>
			<p><?php posts_nav_link(' &#8212; ', __('&laquo; go back'), __('keep looking &raquo;')); ?></p>
		</div>
	<?php include(TEMPLATEPATH."/left_sidebar.php");?>
	<?php include(TEMPLATEPATH."/right_sidebar.php");?>
<?php get_footer(); ?>