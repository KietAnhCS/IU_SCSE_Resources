	<div id="outer">
	<ul id="sidebarwidgeted">
	<?php if ( function_exists('dynamic_sidebar') && dynamic_sidebar(2) ) : else : ?>

		<li id="search">
			<h2>Search</h2>
			<form id="searchform" method="get" action="<?php echo $_SERVER['PHP_SELF']; ?>">
				<p>
					<input type="text" name="s" id="s"  />
					<input type="submit" value="<?php _e('Go'); ?>" class="sub_but" />
				</p>
			</form>
				</li>
 <li id="comments">
    	<h2>Recent Comments</h2>
		<ul>
			<?php include (TEMPLATEPATH . '/simple_recent_comments.php');?>
		<?php if (function_exists('src_simple_recent_comments')) { src_simple_recent_comments(5, 60, '', ''); } ?>
		</ul>
	</li>



				<?php endif; ?>
		</ul>
	</div>