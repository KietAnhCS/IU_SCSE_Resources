<?php
/*
Template Name: Archives
*/
?>

<?php get_header(); ?>

<div id="post">

<div class="post-meta" id="post-<?php the_ID(); ?>">
<h1>Monthly Archives</h1>
<div class="post-content">
<ul><?php wp_get_archives('type=monthly') ?></ul>
</div>
</div>

<div class="post-meta" id="post-<?php the_ID(); ?>">
<h1>Categories Archives</h1>
<div class="post-content">
<ul><?php wp_list_cats('sort_column=name&optioncount=1&feed=RSS') ?></ul>
</div>
</div>

<div class="post-meta" id="post-<?php the_ID(); ?>">
<h1>Latest Archives</h1>
<div class="post-content">
<ul><?php get_archives('postbypost', 100); ?></ul>
</div>
</div>

<div class="post-meta" id="post-<?php the_ID(); ?>">
<h1>Tags Archives</h1>
<div class="post-content">
<?php if(function_exists("UTW_ShowTagsForCurrentPost")) : ?>
<?php UTW_ShowWeightedTagSetAlphabetical("sizedtagcloud","","1000") ?>
<?php else : ?>
<?php wp_tag_cloud('smallest=14&largest=30&'); ?>
<?php endif; ?>
</div>
</div>

</div>

<?php get_sidebar(); ?>
<?php get_footer(); ?>