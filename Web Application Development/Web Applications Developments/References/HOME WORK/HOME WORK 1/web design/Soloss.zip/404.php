<?php get_header(); ?>

<div id="post">


<h2>404 Error - Please Continue To HomePage</h2>


</div>

<?php get_sidebar(); ?>
<?php get_footer(); ?>