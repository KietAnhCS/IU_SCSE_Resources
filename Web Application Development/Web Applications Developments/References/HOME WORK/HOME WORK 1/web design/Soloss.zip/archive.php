<?php get_header(); ?>

<div id="post">

<?php if(have_posts()) : ?>

<?php $post = $posts[0]; // Hack. Set $post so that the_date() works. ?>

<?php /* If this is a category archive */ if (is_day()) { ?>
		<h2>Archive for <?php the_time('F jS, Y'); ?></h2>

	 <?php /* If this is a monthly archive */ } elseif (is_month()) { ?>
		<h2>Archive for <?php the_time('F, Y'); ?></h2>

		<?php /* If this is a yearly archive */ } elseif (is_year()) { ?>
		<h2>Archive for <?php the_time('Y'); ?></h2>

	  <?php /* If this is a search */ } elseif (is_search()) { ?>
		<h2>Search Results</h2>

	  <?php /* If this is an author archive */ } elseif (is_author()) { ?>
		<h2>Author Archive</h2>

		<?php /* If this is a paged archive */ } elseif (isset($_GET['paged']) && !empty($_GET['paged'])) { ?>
		<h2>Blog Archives</h2>

		<?php } ?>

<?php while(have_posts()) : the_post(); ?>

<div class="post-meta" id="post-<?php the_ID(); ?>">

<h1><a href="<?php the_permalink() ?>" rel="bookmark" title="<?php the_title(); ?>"><?php the_title(); ?></a></h1>

<div class="author">
posted by <?php the_author_posts_link(); ?> in <?php the_time('F jS, Y') ?>&nbsp;<?php edit_post_link(__(' Edit'), '|', ''); ?>
</div>

<div class="post-cat">in <?php the_category(', ') ?>&nbsp;&nbsp;
<?php if(function_exists("UTW_ShowTagsForCurrentPost")) : ?>
<?php UTW_ShowTagsForCurrentPost("commalist", array('last'=>' and %taglink%', 'first'=>'Tags: %taglink%',)) ?>
<?php else : ?>
<?php if(function_exists("the_tags")) : ?>
<?php the_tags() ?>
<?php endif; ?>
<?php endif; ?>
</div>

<div class="post-content">
<?php the_excerpt("Continue reading &rarr;"); ?>
</div>

<?php get_social(); ?>

</div>

<?php endwhile; ?>

<div class="post-cat">in <?php the_category(', ') ?>&nbsp;&nbsp;
<?php if(function_exists("UTW_ShowTagsForCurrentPost")) : ?>
<?php UTW_ShowTagsForCurrentPost("commalist", array('last'=>' and %taglink%', 'first'=>'Tags: %taglink%',)) ?>
<?php else : ?>
<?php if(function_exists("the_tags")) : ?>
<?php the_tags() ?>
<?php endif; ?>
<?php endif; ?>
</div>

<?php else: ?>
<h2>Sorry, the archives you looking for had been deleted</h2>
<?php endif; ?>

</div>

<?php get_sidebar(); ?>
<?php get_footer(); ?>