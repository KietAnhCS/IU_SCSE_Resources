<div class="post-social">

<p class="email"><a href="mailto:?Subject=check <?php bloginfo('name'); ?> Out&amp;body=<?php the_permalink(); ?>">email this</a></p>
<p class="deli"><a href="http://del.icio.us/post?url=<?php the_permalink(); ?>&amp;title=<?php the_title(); ?>">Add to deli.cio.us</a></p>
<p class="digg"><a href="http://digg.com/submit?phase=2&amp;url=<?php the_permalink(); ?>&amp;title=<?php the_title(); ?>">Digg it</a></p>
<p class="permalink"><a href="<?php the_permalink() ?>" rel="bookmark" title="<?php the_title(); ?>">Permalink</a></p>

<?php if(is_single()): ?>
<!--  -->
<?php else : ?>
<p class="c-count"><?php comments_popup_link('No Comment', '1 Comment', '% Comments'); ?></p>
<?php endif; ?>

</div>