<div id="sidebar">

<div class="rss-feed">
<p class="feed"><a href="<?php bloginfo('rss2_url') ?>" title="<?php echo wp_specialchars(get_bloginfo('name'), 1) ?> Posts RSS Feed" rel="alternate" type="application/rss+xml">Subscribes to Rss Feeds</a></p>
<p class="updates">get latest updates on site news and site post</p>
</div>

<div id="ad-box">
<a href="#"><img src="<?php bloginfo('stylesheet_directory');?>/images/light_125x125.jpg" alt="ads" border="0" /></a>
<a href="#"><img src="<?php bloginfo('stylesheet_directory');?>/images/freshbooks125x125.gif" alt="ads" width="125" height="125" border="0" /></a>
<a href="#"><img src="<?php bloginfo('stylesheet_directory');?>/images/mosso_125x125.jpg" alt="ads" width="125" height="125" border="0" /></a>
<a href="#"><img src="<?php bloginfo('stylesheet_directory');?>/images/light_125x125.jpg" alt="ads" border="0" /></a>
<a href="#"><img src="<?php bloginfo('stylesheet_directory');?>/images/mosso_125x125.jpg" alt="ads" width="125" height="125" border="0" /></a>
<a href="#"><img src="<?php bloginfo('stylesheet_directory');?>/images/light_125x125.jpg" alt="ads" border="0" /></a>
</div>

<div id="about">
<h3>About</h3>
<div class="sidebar-litbox">
Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Quisque sed felis. Aliquam sit amet felis. Mauris semper, velit semper laoreet dictum, quam diam dictum urna, nec placerat elit nisl in quam. Etiam augue pede, molestie eget, rhoncus at, convallis ut, eros. Aliquam pharetra.
</div>
</div>

<div id="tag">
<h3>Tags</h3>
<div class="sidebar-litbox">
<?php if(function_exists("UTW_ShowTagsForCurrentPost")) : ?>
<?php UTW_ShowWeightedTagSetAlphabetical("sizedtagcloud","","50") ?>
<?php else : ?>
<?php if(function_exists("wp_tag_cloud")) : ?>
<?php wp_tag_cloud('smallest=11&largest=19&'); ?>
<?php endif; ?>
<?php endif; ?>
</div>
</div>

<div id="search">
<h3>Search</h3>
<form method="get" action="<?php echo $_SERVER['PHP_SELF']; ?>">
<p><input name="s" type="text" value="type and search" onfocus="if (this.value == 'type and search') {this.value = '';}" onblur="if (this.value == '') {this.value = 'type and search';}" size="10" tabindex="1" /> </p>
</form>
</div>


<div id="layout">
<div class="layer">
<div class="ulwrap">
<h3>Recent Entries</h3>
<ul>
<?php get_archives('postbypost', 10); ?>
</ul>
</div>

<div class="ulwrap">
<h3>Recent Comments</h3>
<?php if(function_exists("get_recent_comments")) : ?>
<ul>
<?php get_recent_comments(); ?>
</ul>
<?php else : ?>
<ul>
<?php mw_recent_comments(10, false, 50, 35, 40, 'all', '<li><a href="%permalink%" title="%title%"><strong>%author_name%</strong> &raquo; %title%</a></li>','d.m.y, H:i'); ?>
</ul>
<?php endif; ?>
</div>

<div class="ulwrap">
<h3>Most Commented</h3>
<?php if(function_exists("get_hottopics")) : ?>
<ul>
<?php get_hottopics(); ?>
</ul>
<?php else : ?>
<ul>
<li>You must install the most commented plugin here</li>
</ul>
<?php endif; ?>
</div>

</div>
</div>


<div class="sidebars">

<div class="widget-sidebar">

<?php if(function_exists("wp_theme_switcher")) : ?>
<h3>Switcher</h3>
<?php wp_theme_switcher('dropdown'); ?>
<?php endif; ?>

<?php if ( !function_exists('dynamic_sidebar')
|| !dynamic_sidebar(1) ) : ?>

<h3>Categories</h3>
<ul class="list">
<?php wp_list_categories('orderby=id&show_count=0&use_desc_for_title=0&title_li='); ?>
</ul>

<?php if(function_exists("akpc_most_popular")) : ?>
<h3>Popular Topics</h3>
<ul class="list">
<?php akpc_most_popular(); ?>
</ul>
<?php endif; ?>

<h3>Meta</h3>
<ul class="list">
<?php wp_register(); ?>
<li><?php wp_loginout(); ?></li>
<li><a href="http://validator.w3.org/check/referer" title="This page validates as XHTML 1.0 Transitional">Valid XHTML</a></li>
<li><a href="http://jigsaw.w3.org/css-validator/validator?uri=<?php echo get_settings('home'); ?>&amp;usermedium=all">Valid CSS</a></li>
<li><a href="http://wordpress.org/" title="Powered by WordPress, state-of-the-art semantic personal publishing platform.">WordPress</a></li>
<?php wp_meta(); ?>
</ul>

<?php endif; ?>

</div>

<div class="widget-sidebar">

<?php if ( !function_exists('dynamic_sidebar')
|| !dynamic_sidebar(2) ) : ?>


<h3>Recent Comments</h3>
<ul class="list">
<?php mw_recent_comments(10, false, 50, 35, 40, 'all', '<li><a href="%permalink%" title="%title%"><strong>%author_name%</strong> &raquo; %title%</a></li>','d.m.y, H:i'); ?>
</ul>

<h3>Monthly Archives</h3>
<ul class="list">
<?php wp_get_archives('type=monthly&limit=12'); ?>
</ul>

<h3>Daily Archives</h3>
<ul class="list">
<?php wp_get_archives('type=daily&limit=15'); ?>
</ul>

<h3>Links</h3>
<ul class="list">
<?php get_links(-1, '<li>', '</li>', ' - '); ?>
</ul>

<?php endif; ?>

</div>

</div>

</div>