<?php get_header(); ?>

<div id="post">

<?php if(have_posts()) : ?>

<?php while(have_posts()) : the_post(); ?>

<div class="post-meta" id="post-<?php the_ID(); ?>">

<h1><a href="<?php the_permalink() ?>" rel="bookmark" title="<?php the_title(); ?>"><?php the_title(); ?></a></h1>

<div class="author">
posted by <?php the_author_posts_link(); ?> in <?php the_time('F jS, Y') ?>&nbsp;<?php edit_post_link(__(' Edit'), '|', ''); ?>
</div>

<div class="post-cat">in <?php the_category(', ') ?>&nbsp;&nbsp;
<?php if(function_exists("UTW_ShowTagsForCurrentPost")) : ?>
<?php UTW_ShowTagsForCurrentPost("commalist", array('last'=>' and %taglink%', 'first'=>'Tags: %taglink%',)) ?>
<?php else : ?>
<?php if(function_exists("the_tags")) : ?>
<?php the_tags() ?>
<?php endif; ?>
<?php endif; ?>
</div>

<div class="post-content">
<?php the_content("Continue reading &rarr;"); ?>
</div>

<?php get_social(); ?>

</div>

<?php endwhile; ?>

<div class="post-navigator">
<?php link_pages('<strong>Pages:</strong> ', '', 'number'); ?>
</div>

<?php else: ?>
<h2>Sorry, the page you looking for had been deleted</h2>
<?php endif; ?>

</div>

<?php get_sidebar(); ?>
<?php get_footer(); ?>