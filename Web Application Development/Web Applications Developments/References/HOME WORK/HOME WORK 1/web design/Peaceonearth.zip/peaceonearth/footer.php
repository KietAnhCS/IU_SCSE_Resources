</div><!--/page -->
</div><!--/wrapper -->
<div id="footerbg">
  <div id="footer">
	<!--about text start -->
	<div class="footer-meta">
		<h4>Meta</h4>
			<ul>
								<li><a href="<?php echo get_settings('home'); ?>/wp-login.php">Login</a></li>
				<li><a href="http://validator.w3.org/check/referer" title="This page validates as XHTML 1.0 Transitional">Valid <abbr title="eXtensible HyperText Markup Language">XHTML</abbr></a></li>
				<li><a href="http://wordpress.org/" title="Powered by WordPress, state-of-the-art semantic personal publishing platform.">WordPress</a></li>
				<li class="rss"><a href="feed:<?php echo get_settings('home'); ?>/?feed=rss2">Entries RSS</a></li>
				<li class="rss"><a href="feed:<?php echo get_settings('home'); ?>/?feed=comments-rss2" class="rss">Comments RSS</a></li>
			</ul>
				<div class="links-bottom">designed by: <a href="http://www.makequick.com">Online Website Builder</a> and: <a href="http://www.webhostinggeeks.com">Web Hosting Geeks</a> | available free at: <a href="http://www.topwpthemes.com">Top Wordpress Themes </a></div> 
	</div>
	<!--about text end -->

	
  <hr class="clear" />
  </div>
<!--/footer -->
<div id="credits">
</div>
  </div>
<div style="color: #303030; margin-top: -148px; background-image: url(<?php bloginfo('stylesheet_directory'); ?>/images/footer-bg1.gif); width: 100%; height: 148px;"></div>
</body>
</html>