		<div class="clearer">&nbsp;</div>

	</div>

	<div id="footer">

		<div class="left">&#169; <?=date('Y') ?> <?php bloginfo('name')?></div>

		<div class="right"><a href="http://templates.arcsin.se/">Wordpress theme</a> by <a href="http://arcsin.se/">Arcsin</a></div>

		<div class="clearer">&nbsp;</div>
	
	</div>

</div>
<div id="layout_edgebottom"></div>
</div>

<?php wp_footer(); ?>

</body>
</html>