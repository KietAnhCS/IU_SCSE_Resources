<?php get_header(); ?>

	<div class="post">

		<div class="post_title"><h1>Not Found</h1></div>

		<div class="post_body">
			
			<p>Sorry, but you are looking for something that isn't here.</p>

		</div>

		<div class="post_bottom"></div>

	</div>		

<?php get_sidebar(); ?>

<?php get_footer(); ?>