<?php get_header(); ?>
<div id="content">
<?php include(TEMPLATEPATH."/l_sidebar.php");?>
<div id="contentleft">
					<?php if (have_posts()) : ?>

					<?php $post = $posts[0]; // Hack. Set $post so that the_date() works. ?>
					<?php /* If this is a category archive */ if (is_category()) { ?>
					<h3 class="arch"><u>Archive for the '<?php echo single_cat_title(); ?>' Category </u></h3>

					<?php /* If this is a daily archive */ } elseif (is_day()) { ?>
					<h3 class="arch"><u>Archive for <?php the_time('F jS, Y'); ?></u></h3>

				 <?php /* If this is a monthly archive */ } elseif (is_month()) { ?>
					<h3 class="arch"><u>Archive for <?php the_time('F, Y'); ?></u></h3>

					<?php /* If this is a yearly archive */ } elseif (is_year()) { ?>
					<h3 class="arch"><u>Archive for <?php the_time('Y'); ?></u></h3>

					<?php /* If this is a search */ } elseif (is_search()) { ?>
					<h3 class="arch"><u>Search Results for "<?echo $s; ?>"</u></h3>

					<?php /* If this is an author archive */ } elseif (is_author()) { ?>
					<h3 class="arch"><u>Author Archive</u></h3>

					<?php /* If this is a paged archive */ } elseif (isset($_GET['paged']) && !empty($_GET['paged'])) { ?>
					<h3 class="arch"><u>Blog Archives</u></h3>

					<?php } ?>
		 	<?php while (have_posts()) : the_post(); ?>
		<h1><a href="<?php the_permalink() ?>" rel="bookmark"><?php the_title(); ?></a></h1>
		<?php the_excerpt(__('Read more'));?><div style="clear:both;"></div>
		<p class="detpost">Posted on <?php the_time('F j, Y'); ?> Filed Under <?php the_category(', ') ?> | <?php comments_popup_link('Leave a Comment', '1 Comment', '% Comments'); ?></p>
		<!--
		<?php trackback_rdf(); ?>
		-->
	<?php endwhile; else: ?>
	<p><?php _e('Sorry, no posts matched your criteria.'); ?></p><?php endif; ?>
	<?php posts_nav_link(' &#8212; ', __('&laquo; go back'), __('keep looking &raquo;')); ?>
</div>
<?php include(TEMPLATEPATH."/r_sidebar.php");?>
<!-- The main column ends  -->
<?php get_footer(); ?>