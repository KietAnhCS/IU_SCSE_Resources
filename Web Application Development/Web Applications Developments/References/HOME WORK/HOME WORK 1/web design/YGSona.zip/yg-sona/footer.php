<!-- begin footer -->
<div style="clear:both;"></div>
<div id="footerbg">
	<div id="footer">
		<div id="footerleft">
			<h3>Recent Comments</h3>
			<ul>
				<?php include (TEMPLATEPATH . '/simple_recent_comments.php');?>
				<?php if (function_exists('src_simple_recent_comments')) { src_simple_recent_comments(5, 60, '', ''); } ?>
			</ul>
		</div>
		<div id="footermiddle1">
			<h3>Archives</h3>
			<ul>
				<?php wp_get_archives('type=monthly'); ?>
			</ul>
		</div>
		<div id="footermiddle2">
			<h3>About Me</h3>
			<p>Something About You Could go here.  Update this in footer.php present in theme folder</p><br /><p>Copyright &copy; <?php echo date(Y); ?> <?php bloginfo('name'); ?> - Theme Design by <a href="http://www.ygoy.com">YGoY</a></p>
		</div>
	</div>
	<div style="clear:both;"></div>
</div>
</div>
<?php do_action('wp_footer'); ?>

</body>
</html>