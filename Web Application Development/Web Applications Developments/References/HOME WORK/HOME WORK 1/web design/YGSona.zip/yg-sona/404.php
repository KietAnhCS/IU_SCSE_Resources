<?php get_header(); ?>
<div id="content">
	<div id="contentleft">
		<h1>Not Found, Error 404</h1>
		<p>The page you are looking for no longer exists.</p>
	</div>
	<?php include(TEMPLATEPATH."/l_sidebar.php");?>
	<?php include(TEMPLATEPATH."/r_sidebar.php");?>
</div>
<?php get_footer(); ?>