<div id="l_sidebar">
	<h2>Recently Written</h2>
	<ul>
		<?php get_archives('postbypost', 10); ?>
	</ul>
	<h2>Categories</h2>
	<ul>
		<?php wp_list_cats('sort_column=name'); ?>
	</ul>
</div>

