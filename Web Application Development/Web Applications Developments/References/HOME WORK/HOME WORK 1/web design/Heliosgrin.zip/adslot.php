<div id="adslot">
<div class="ad"><a href="#"><img src="<?php bloginfo('stylesheet_directory');?>/images/light_125x125.jpg" alt="ads" width="125" height="125" /></a></div>
<div class="ad"><a href="#"><img src="<?php bloginfo('stylesheet_directory');?>/images/df_125x125.gif" alt="ads" width="125" height="125" /></a></div>
<div class="ad"><a href="#"><img src="<?php bloginfo('stylesheet_directory');?>/images/mosso_125x125.jpg" alt="ads" width="125" height="125" /></a></div>
<div class="ad"><a href="#"><img src="<?php bloginfo('stylesheet_directory');?>/images/freshbooks125x125.gif" alt="ads" width="125" height="125" /></a></div>
</div>