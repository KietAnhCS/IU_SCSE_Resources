<?php get_header(); ?>

<div id="post">

<h2>404 ERROR - Please return back to homepage</h2>

</div>

<?php get_sidebar(); ?>
<?php get_footer(); ?>