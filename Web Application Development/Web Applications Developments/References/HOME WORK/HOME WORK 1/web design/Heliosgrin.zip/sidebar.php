<div id="sidebar">

<div id="rssfeed"><a href="<?php bloginfo('rss2_url') ?>" title="<?php echo wp_specialchars(get_bloginfo('name'), 1) ?> Posts RSS Feed" rel="alternate" type="application/rss+xml"><img src="<?php bloginfo('stylesheet_directory');?>/images/subscribes.gif" alt="feeds" border="0" /></a></div>

<h3>Search</h3>
<div class="sidebox">
<form method="get" action="<?php echo $_SERVER['PHP_SELF']; ?>">
<p><input name="s" type="text" class="sbm-box" value="type and search" onfocus="if (this.value == 'type and search') {this.value = '';}" onblur="if (this.value == '') {this.value = 'type and search';}" size="10" tabindex="1" /> </p>
</form>
</div>
<div class="close-ul"></div>

<?php if(function_exists("wp_theme_switcher")) : ?>
<h3>Switcher</h3>
<?php wp_theme_switcher('dropdown'); ?>
<div class="close-ul"></div>
<?php endif; ?>

<?php if ( !function_exists('dynamic_sidebar')
|| !dynamic_sidebar(1) ) : ?>


<div class="sortable">
<h3>Categories</h3>
<ul class="list">
<?php wp_list_categories('orderby=id&show_count=0&use_desc_for_title=0&title_li='); ?>
</ul>
<div class="close-ul"></div>
</div>

<?php if(function_exists("akpc_most_popular")) : ?>
<div class="sortable">
<h3>Popular Topics</h3>
<ul class="list">
<?php akpc_most_popular(); ?>
</ul>
<div class="close-ul"></div>
</div>
<?php endif; ?>

<div class="sortable">
<h3>Latest Comments</h3>
<ul class="list">
<?php mw_recent_comments(6, false, 50, 35, 40, 'all', '<li><a href="%permalink%" title="%title%"><strong>%author_name%</strong> &raquo; %title%</a></li>','d.m.y, H:i'); ?> 
</ul>
<div class="close-ul"></div>
</div>

<div class="sortable">
<h3>Monthly Archives</h3>
<ul class="list">
<?php wp_get_archives('type=monthly&limit=12'); ?>
</ul>
<div class="close-ul"></div>
</div>

<div class="sortable">
<h3>Daily Archives</h3>
<ul class="list">
<?php wp_get_archives('type=daily&limit=6'); ?>
</ul>
<div class="close-ul"></div>
</div>


<div class="sortable">
<h3>Friends</h3>
<ul class="list">
<?php get_links(-1, '<li>', '</li>', ' - '); ?>
</ul>
<div class="close-ul"></div>
</div>

<div class="sortable">
<h3>Meta</h3>
<ul class="list">
<?php wp_register(); ?>
<li><?php wp_loginout(); ?></li>
<li><a href="http://validator.w3.org/check/referer" title="This page validates as XHTML 1.0 Transitional">Valid XHTML</a></li>
<li><a href="http://jigsaw.w3.org/css-validator/validator?uri=<?php echo get_settings('home'); ?>&amp;usermedium=all">Valid CSS</a></li>
<li><a href="http://wordpress.org/" title="Powered by WordPress, state-of-the-art semantic personal publishing platform.">WordPress</a></li>
<?php wp_meta(); ?>
</ul>
<div class="close-ul"></div>
</div>

<?php endif; ?>


</div>