
<a href="http://digg.com/submit?phase=2&amp;url=<?php the_permalink(); ?>&amp;title=<?php the_title(); ?>">Digg it</a>&nbsp;&nbsp;&nbsp;&nbsp;
<a href="http://del.icio.us/post?url=<?php the_permalink(); ?>&amp;title=<?php the_title(); ?>">Delicious it</a>&nbsp;&nbsp;&nbsp;&nbsp;
<a href="http://www.stumbleupon.com/submit?url=<?php the_permalink(); ?>&amp;title=<?php the_title(); ?>">Stumble it</a>&nbsp;&nbsp;&nbsp;&nbsp;
<a href="http://technorati.com/faves?add=<?php the_permalink(); ?>">Favourite it</a>&nbsp;&nbsp;&nbsp;&nbsp;