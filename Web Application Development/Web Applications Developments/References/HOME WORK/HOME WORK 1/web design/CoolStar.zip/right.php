<?php // Place your ads here. Wrap in <p> tags, put <p class="aligncenter"> to center the content of that part. ?>
<div class="rightsidebar">
	<h2>Sponsored Links</h2>
	<p><a href="#"><img src="<?php bloginfo('template_directory'); ?>/images/sponsor1.jpg" alt="Sponsor" /></a></p>
	<p><a href="#"><img src="<?php bloginfo('template_directory'); ?>/images/sponsor2.jpg" alt="Sponsor" /></a></p>
	<p><a href="#"><img src="<?php bloginfo('template_directory'); ?>/images/sponsor3.jpg" alt="Sponsor" /></a></p>
	<h2>Advertisement</h2>
	<p class="aligncenter">
		<?php // Fill in your Adsense Publisher Number below ?>
		<script type="text/javascript"><!--
		google_ad_client = "pub-xxxxxxxxxxxxxxxx";
		google_ad_width = 160;
		google_ad_height = 600;
		google_ad_format = "160x600_as";
		google_ad_type = "text_image";
		google_ad_channel ="";
		google_color_border = "63bd47";
		google_color_bg = "FFFFFF";
		google_color_link = "3a6bff";
		google_color_text = "000000";
		google_color_url = "63bd47";
		//--></script>
		<script type="text/javascript"
		  src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
		</script>
	</p>
</div>