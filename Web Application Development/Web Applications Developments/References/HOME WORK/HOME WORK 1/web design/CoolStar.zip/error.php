<div class="posttop"></div>
<div class="post">
	<div class="date"></div>
	<h2 class="title">Not Found</h2>
	<p>The page your requested could not be found. Please return to the <a href="<?php bloginfo('home'); ?>">home page</a> and continue from there.</p>
</div>
<div class="postbottom"></div>
<div class="postbar">

</div>
<div class="postbarbottom"></div>