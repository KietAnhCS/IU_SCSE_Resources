INSTALLATION:

Upload the theme directory to your ftp inside the /wp-content/themes/ directory.
Then go to your Wordpress admin panel (yourdomain.com/wp-admin) and click the Presentation tab.
Now you'll see that theme there. Click on it and you're done!

PUT YOUR OWN ADS IN:

You can put your own ads in this theme easily. Just open the leftad.php and contentad.php files and put in your ad code.

!----------!

This theme is Designed By: ElegantWPThemes.com You can use this theme freely, as long as you leave the designer link in the footer.