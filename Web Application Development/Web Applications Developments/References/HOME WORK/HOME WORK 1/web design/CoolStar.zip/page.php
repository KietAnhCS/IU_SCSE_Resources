<?php get_header(); ?>

<div class="content">
	<?php include(TEMPLATEPATH . "/contentad.php"); ?>

		<?php if (have_posts()) : while (have_posts()) : the_post(); ?>
			
			<div class="posttop"></div>
			<div class="post">
				<div class="date"><?php the_time('j'); ?><br /><?php the_time('M'); ?></div>
				<h2 class="title"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2>
				<p class="postinfo">Written by <?php the_author(); ?> on <?php the_time('F jS, Y'); ?></p>
				<?php the_content(); ?>
				<?php wp_link_pages(array('before' => '<div class="pagelinks">Pages: ', 'after' => '</div>', 'next_or_number' => 'number')); ?>
			</div>
			<div class="postbottom"></div>
			<div class="postbar">
				<div class="cats">Filed under: <?php the_category(', '); ?></div>
				<div class="coms"><a href="<?php the_permalink(); ?>#comments"><?php comments_number('No Comments', 'One Comment', '% Comments'); ?></a></div>
				<div class="clear"></div>
			</div>
			<div class="postbarbottom"></div>
			
		<?php endwhile; endif; ?>
						
	<?php include(TEMPLATEPATH . "/contentad.php"); ?>
</div>

<?php get_sidebar(); ?>

<?php include(TEMPLATEPATH . "/right.php"); ?>

<?php get_footer(); ?>