<?php get_header(); ?>

<div class="content">
	<?php include(TEMPLATEPATH . "/contentad.php"); ?>

	<?php include(TEMPLATEPATH . "/error.php"); ?>
				
	<?php include(TEMPLATEPATH . "/contentad.php"); ?>
</div>

<?php get_sidebar(); ?>

<?php include(TEMPLATEPATH . "/right.php"); ?>

<?php get_footer(); ?>