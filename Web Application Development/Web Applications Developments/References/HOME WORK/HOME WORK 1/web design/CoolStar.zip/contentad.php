<div class="contentad">
	<?php // Fill in your Adsense Publisher Number below ?>
	<script type="text/javascript"><!--
	google_ad_client = "pub-xxxxxxxxxxxxxxxx";
	google_ad_width = 468;
	google_ad_height = 60;
	google_ad_format = "468x60_as";
	google_ad_type = "text_image";
	google_ad_channel ="";
	google_color_border = "FFFFFF";
	google_color_bg = "FFFFFF";
	google_color_link = "000000";
	google_color_text = "000000";
	google_color_url = "000000";
	//--></script>
	<script type="text/javascript"
	  src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
	</script>
</div>
