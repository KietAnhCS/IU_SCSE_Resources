			<div class="clear"></div>
			
		</div>
		<div class="centershadowbottom"></div>
		
		<div class="bottomblocks">
			<div class="block">
				<div class="blockinner">
					<h1>Featured Post</h1>
					<?php query_posts('category_name=featured&showposts=1'); ?>
					<?php while (have_posts()) : the_post(); ?>
						<a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
						<p class="postinfo">by <?php the_author(); ?> on <?php the_time('F jS, Y'); ?></p>
						<?php the_content('Read more &raquo;'); ?>
					<?php endwhile;?>
				</div>
			</div>
			<div class="block">
				<div class="blockinner">
					<h1>Popular Post</h1>
					<?php query_posts('category_name=popular&showposts=1'); ?>
					<?php while (have_posts()) : the_post(); ?>
						<a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
						<p class="postinfo">by <?php the_author(); ?> on <?php the_time('F jS, Y'); ?></p>
						<?php the_content('Read more &raquo;'); ?>
					<?php endwhile;?>
				</div>
			</div>
			<div class="block lastblock">
				<div class="blockinner">
					<h1>Recent Comments</h1>
					<?php $comments = $wpdb->get_results("SELECT comment_author, comment_author_url, comment_ID, comment_post_ID, comment_content FROM $wpdb->comments WHERE comment_approved = '1' ORDER BY comment_date_gmt DESC LIMIT 4"); ?>
					<?php
					if ( $comments ) : foreach ($comments as $comment) :
						echo '<a href="'. get_permalink($comment->comment_post_ID) . '#comment-'. $comment->comment_ID .'">'. get_comment_author() .'</a><br /><p>'. $comment->comment_content .'</p><div class="recentcommentsline"></div>';
					endforeach; endif;?>
				</div>
			</div>
		</div>
		
		<div class="copyright">Copyright &copy; <?php print date('Y'); ?> <?php bloginfo('name'); ?>. All Rights Reserved. Designed by <a title="Free Wordpress Themes" target="_blank" href="http://www.elegantwpthemes.com">Elegant WP Themes</a></div>
		
	</div>
	
</body>
</html>