<?php get_header(); ?>

	<div id="content">
<div id="entry">
		<h2">Error 404 - Not Found</h2>
</div>
	</div>

<?php get_sidebar(); ?>

<?php get_footer(); ?>