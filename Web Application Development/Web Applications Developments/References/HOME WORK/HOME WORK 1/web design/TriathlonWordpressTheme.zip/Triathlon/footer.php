<div id="footer">
<p>&copy; <?php echo date('Y');?> <a href="<?php bloginfo('siteurl');?>/" title="<?php bloginfo('name');?>" ><strong><?php bloginfo('name');?></strong></a><br />
<a href="http://www.templatepanic.com/article/triathlon-wordpress-theme" title="Triathlon Wordpress Theme">Wordpress Theme</a> by <a href="https://www.usasportstraining.com/" title="Triathlon Training">Triathlon Training</a></p>
</div> <!-- end footer -->

</div> <!-- end box -->
</body>
</html>
