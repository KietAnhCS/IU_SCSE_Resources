<div class="footer">
	<p><?php echo sprintf(__("Powered by <a href='http://wordpress.org/' title='%s'><strong>WordPress</strong></a>"), __("Powered by WordPress, state-of-the-art semantic personal publishing platform.")); ?> - Theme <b> Design by - <a href="http://www.ygoy.com">YGoY</a></p>
</div>
<?php wp_footer(); ?>
</body>
</html>


