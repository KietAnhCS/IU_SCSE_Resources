<div id="rightboxy">
	<div id="wrapper1">
		<div id="content1" style="width:320px;float:none;margin-left:5px;">
			<span class="tab" title="first"><div class="tabtxt"><b><a href="#">Most Popular</a></b></div></span>
			<div class="tab"><h6 class="tabtxt" title="second"><a href="#">Categories</a></h6></div>
			<div class="boxholder">
				<div class="box1" >
					<div class="containe">
						<ul>
							<?php if (function_exists('get_most_viewed')): ?>
							<?php get_most_viewed('both',5); ?>
							<?php endif; ?>
						</ul>
					</div>
			</div>
			<div class="box1" style="overflow: hidden; height: 0px;">
				<div class="containe">
				<ul>
					<?php wp_list_cats('sort_column=name&hierarchical=1') ?>
				</ul>
				</div>
			</div>
		</div>
	</div>
	<script type="text/javascript">
		Element.cleanWhitespace('content1');
		init();
	</script>
	<h2>Recent Enteries</h2>
	<?php query_posts('showposts=5'); ?>
	<ul class="commento">
		<?php while (have_posts()) : the_post(); ?>
			<li><a href="<?php the_permalink() ?>" rel="bookmark" title="<?php _e('Permanent link to'); ?> <?php the_title(); ?>"><?php the_title(); ?></a> - <?php the_time('m-d-Y') ?></small></li>
		<?php endwhile;?>
	</ul>
	<h2>Recent Comments</h2>
	<ul class="commento">
		<?php include (TEMPLATEPATH . '/simple_recent_comments.php');?>
		<?php if (function_exists('src_simple_recent_comments')) { src_simple_recent_comments(3, 60, '', ''); } ?>
	</ul>
	<table class="sofT" cellspacing="0">
		<tr>
			<td class="helpBod" valign="top"><h2 style="width:90%;"><?php _e('Archives'); ?></h2>
				<ul>
					<?php wp_get_archives('type=monthly&limit=5'); ?>
				</ul>
			</td>
			<td class="helpBod" valign="top"><h2>Meta</h2>
				<ul>
					<?php wp_register(); ?>
					<li><?php wp_loginout(); ?></li>
					<li><a href="http://validator.w3.org/check/referer" title="This page validates as XHTML 1.0 Transitional">Valid <abbr title="eXtensible HyperText Markup Language">XHTML</abbr></a></li>
					<li><a href="http://gmpg.org/xfn/"><abbr title="XHTML Friends Network">XFN</abbr></a></li>
					<li><a href="http://wordpress.org/" title="Powered by WordPress, state-of-the-art semantic personal publishing platform.">WordPress</a></li>
					<?php wp_meta(); ?>
				</ul>
			</td>
		</tr>
	</table>
</div>