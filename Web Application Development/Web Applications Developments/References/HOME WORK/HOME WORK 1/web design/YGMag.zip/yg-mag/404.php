<?php get_header(); ?>
<div id="primaryContent">
		<h1>Error 404 - Not Found</h1>
</div>
<?php get_sidebar(); ?>

</div>
</div>

<?php get_footer(); ?>

