<?php get_header(); ?>
<div id="primaryContent">
  <?php if (have_posts()) : while (have_posts()) : the_post(); ?>
        <h3><a href="<?php echo get_permalink() ?>" rel="bookmark" title="Permanent Link: <?php the_title(); ?>"><?php the_title(); ?></a></h3>
		<p class="arc"><?php the_category(', ') ?></span> <span class="post-calendar"><?php the_time('F jS, Y') ?></p>
		<?php the_content('<p class="serif">Read the rest of this entry &raquo;</p>'); ?>
		<?php link_pages('<p><strong>Pages:</strong> ', '</p>', 'number'); ?>
		<?php comments_template(); ?>
			<?php endwhile; else: ?>
		<p>Sorry, no posts matched your criteria.</p>
<?php endif; ?>
		<div class="navigation">
			<span class="previous-entries"><?php next_posts_link('Previous Entries') ?></span> <span class="next-entries"><?php previous_posts_link('Next Entries') ?></span>
		</div>
</div>
<?php get_sidebar(); ?>

</div>
</div>

<?php get_footer(); ?>

