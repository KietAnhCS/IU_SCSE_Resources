<?php get_header(); ?>
		<div id="main">
			<div class="col1">
				<div id="screencast">
					<div id="screencast-left">
						<h3>Recent Enteries</h3>
						<?php query_posts('showposts=5'); ?>
						<ul>
						<?php while (have_posts()) : the_post(); ?>

							<li><a href="<?php the_permalink() ?>" rel="bookmark" title="<?php _e('Permanent link to'); ?> <?php the_title(); ?>"><?php the_title(); ?></a> - <?php the_time('m-d-Y') ?></small></li>
						<?php endwhile;?>
						</ul>

					</div>
					<div id="screencast-content">
						<h3>Recent Comments</h3>
						<ul>
								<?php include (TEMPLATEPATH . '/simple_recent_comments.php');?>
								<?php if (function_exists('src_simple_recent_comments')) { src_simple_recent_comments(3, 60, '', ''); } ?>
						</ul>
					</div>
				</div>
			</div>
		</div>
		<div id="primaryContent">
		<h2>Latest Additions</h2>
		<?php
			query_posts('showposts=5&offset=5');
		?>
		<?php if (have_posts()) : ?>
			<?php while (have_posts()) : the_post(); ?>
				<h3><a href="<?php the_permalink() ?>" rel="bookmark" title="Permanent Link to <?php the_title(); ?>"><?php the_title(); ?></a></h3>
				<?php the_excerpt(__('Readmore �'));?><a href="<?php the_permalink() ?>" style="margin:0 0 5px 12px;color:#558833">Read More..&gt;&gt;</a>
				<?php endwhile; ?>
			<?php else : ?>
				<h2 class="center">Not Found</h2>
				<p class="center">Sorry, but you are looking for something that isn't here.</p>
		<?php endif; ?>
		<div class="navigation">
			<span class="previous-entries"> <?php next_posts_link('&laquo; Previous Entries') ?></span> <span class="next-entries"><?php previous_posts_link('Next Entries &raquo;') ?> </span>
		</div>
	</div>
	<?php include (TEMPLATEPATH . '/sidebar_home.php');?>
	</div>
</div>
<?php get_footer(); ?>

