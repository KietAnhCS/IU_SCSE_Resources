<?php get_header(); ?>
<div id="primaryContent">
  <?php if (have_posts()) : while (have_posts()) : the_post(); ?>
        <h2><a href="<?php echo get_permalink() ?>" rel="bookmark" title="Permanent Link: <?php the_title(); ?>"><?php the_title(); ?></a></h2>
		<p class="arc">Posted at <?php the_time(); ?> | Filed Under: <?php the_category(', ') ?></p>
	<?php the_excerpt(__('Read more'));?><p><a href="<?php the_permalink() ?>" rel="bookmark">Read More></a></p>
		<?php link_pages('<p><strong>Pages:</strong> ', '</p>', 'number'); ?>

		<?php comments_template(); ?>
			<?php endwhile; else: ?>
		<p>Sorry, no posts matched your criteria.</p>
<?php endif; ?>
		<div class="navigation">
			<span class="previous-entries"><?php next_posts_link('Previous Entries') ?></span> <span class="next-entries"><?php previous_posts_link('Next Entries') ?></span>
		</div>
</div>
<?php get_sidebar(); ?>

</div>
</div>

<?php get_footer(); ?>

